package TheActandClubs;

public class Leader extends Person {
	public String a_class;
	public String college;
	public Leader()
	{
		super();
		a_class="1601��";
		this.college="����ѧԺ";
	}
	public Leader(String a,String b) {
		// TODO Auto-generated constructor stub
		super();
		this.a_class=a;
		this.college=b;
	}

}
