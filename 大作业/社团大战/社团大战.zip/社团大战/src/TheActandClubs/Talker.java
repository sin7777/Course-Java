
package TheActandClubs;

public class Talker extends Person {
	private String workplace="���пƼ���ѧ";
	public Talker(String s) {
		super();
		this.workplace=s;
		// Auto-generated constructor stub
	}
	public Talker()
	{}
	public void setWorkplace(String s)
	{
		this.workplace=s;
	}
	public String getWorkplace()
	{
		return this.workplace;
	}
}
