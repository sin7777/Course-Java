package TheActandClubs;

public class Speech extends Activity {
	private Talker speaker;
	public Speech() {
		// TODO Auto-generated constructor stub
	}

}
